"""Filesystem path utilities for ClassVision AI."""

from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_DIR = BASE_DIR / "config"
ASSETS_DIR = BASE_DIR / "assets"
ICONS_DIR = ASSETS_DIR / "icons"
LOGS_DIR = BASE_DIR / "logs"
TEMP_DIR = BASE_DIR / "temp"

# Ensure directories exist
for directory in (LOGS_DIR, TEMP_DIR, ICONS_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Specific file paths
LOG_FILE = LOGS_DIR / "classvision.log"
TEMP_SCREENSHOT = TEMP_DIR / "current_slide.png"
