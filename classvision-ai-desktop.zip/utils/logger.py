"""Logging configuration for ClassVision AI with privacy guardrails."""

import logging
import sys
from utils.paths import LOG_FILE

logger = logging.getLogger("ClassVisionAI")


def setup_logger(debug: bool = False) -> logging.Logger:
    """Configure logger with standard formatting.
    Guarantees privacy: No raw audio or secrets are logged."""
    if logger.hasHandlers():
        return logger

    level = logging.DEBUG if debug else logging.INFO
    logger.setLevel(level)

    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler
    try:
        file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not initialize log file: {e}")

    return logger
