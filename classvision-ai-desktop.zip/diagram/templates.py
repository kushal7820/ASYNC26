"""Educational diagram templates for demo mode, testing, and offline fallback."""

from ai.diagram_schema import DiagramSpecification

# 1. TCP Three-Way Handshake
TCP_HANDSHAKE_DIAGRAM = DiagramSpecification(
    title="TCP Three-Way Handshake",
    diagram_type="sequence",
    description="Connection establishment protocol ensuring reliable transport layer communication between client and server.",
    nodes=[
        {"id": "client", "label": "Client (Active Open)", "description": "Initiates connection, chooses SEQ = 100", "highlight": False},
        {"id": "syn", "label": "1. SYN Packet", "description": "SYN=1, ACK=0, Seq=X", "highlight": True},
        {"id": "server", "label": "Server (Passive Open)", "description": "Listening on port, allocates TCB buffer", "highlight": False},
        {"id": "synack", "label": "2. SYN-ACK Packet", "description": "SYN=1, ACK=1, Seq=Y, Ack=X+1", "highlight": True},
        {"id": "ack", "label": "3. ACK Packet", "description": "SYN=0, ACK=1, Seq=X+1, Ack=Y+1", "highlight": False},
        {"id": "connected", "label": "ESTABLISHED State", "description": "Full-duplex bidirectional stream ready", "highlight": False},
    ],
    connections=[
        {"from": "client", "to": "syn", "label": "Sends SYN", "style": "solid"},
        {"from": "syn", "to": "server", "label": "Delivered to Server", "style": "solid"},
        {"from": "server", "to": "synack", "label": "Replies SYN-ACK", "style": "solid"},
        {"from": "synack", "to": "client", "label": "Delivered to Client", "style": "solid"},
        {"from": "client", "to": "ack", "label": "Final ACK Confirm", "style": "solid"},
        {"from": "ack", "to": "connected", "label": "Data Transfer Ready", "style": "solid"},
    ]
)

# 2. Photosynthesis Reaction Cycle
PHOTOSYNTHESIS_DIAGRAM = DiagramSpecification(
    title="Photosynthesis: Light Reactions & Calvin Cycle",
    diagram_type="cycle",
    description="Dual-phase biological process converting photon energy into chemical sugars.",
    nodes=[
        {"id": "sunlight", "label": "Solar Photons + H2O", "description": "Absorbed by Thylakoid Chlorophyll", "highlight": False},
        {"id": "light_rxn", "label": "Light Reactions", "description": "Produces ATP, NADPH, and O2 byproduct", "highlight": True},
        {"id": "atp_nadph", "label": "ATP + NADPH Energy", "description": "High-energy electron carriers", "highlight": False},
        {"id": "calvin_cycle", "label": "Calvin Cycle (Stroma)", "description": "Fixes CO2 into G3P / Glucose", "highlight": True},
        {"id": "glucose", "label": "Sugar (C6H12O6)", "description": "Cellular biomass & plant energy", "highlight": False},
        {"id": "adp_nadp", "label": "ADP + NADP+ Recycled", "description": "Returns to Thylakoid for recharge", "highlight": False},
    ],
    connections=[
        {"from": "sunlight", "to": "light_rxn", "label": "Water splitting (photolysis)", "style": "solid"},
        {"from": "light_rxn", "to": "atp_nadph", "label": "Energy transfer", "style": "solid"},
        {"from": "atp_nadph", "to": "calvin_cycle", "label": "Powers carbon fixation", "style": "solid"},
        {"from": "calvin_cycle", "to": "glucose", "label": "Synthesizes", "style": "solid"},
        {"from": "calvin_cycle", "to": "adp_nadp", "label": "Dephosphorylated", "style": "dashed"},
        {"from": "adp_nadp", "to": "light_rxn", "label": "Re-enters Light Reaction", "style": "dashed"},
    ]
)

# 3. Monolith vs Microservices Comparison
ARCHITECTURE_COMPARISON_DIAGRAM = DiagramSpecification(
    title="Monolithic vs Microservices Architecture",
    diagram_type="comparison",
    description="Architectural contrast between single-binary deployment and distributed modular services.",
    nodes=[
        {"id": "monolith", "label": "Monolithic Architecture", "description": "Unified codebase, single database, tight coupling", "highlight": False},
        {"id": "mono_pro", "label": "Pros: Simple dev, easy atomic transactions", "description": "Straightforward initial MVP velocity", "highlight": False},
        {"id": "mono_con", "label": "Cons: Single point of failure, scaling bottlenecks", "description": "Difficult horizontal partial scaling", "highlight": False},
        {"id": "microservices", "label": "Microservices Architecture", "description": "Decoupled bounded contexts, API gateways, independent DBs", "highlight": True},
        {"id": "micro_pro", "label": "Pros: Independent deployability, fault isolation", "description": "Team autonomy & tech stack flexibility", "highlight": True},
        {"id": "micro_con", "label": "Cons: Distributed network latency, eventual consistency", "description": "Operational and observability overhead", "highlight": False},
    ],
    connections=[
        {"from": "monolith", "to": "mono_pro", "label": "Benefits", "style": "solid"},
        {"from": "monolith", "to": "mono_con", "label": "Tradeoffs", "style": "solid"},
        {"from": "microservices", "to": "micro_pro", "label": "Benefits", "style": "solid"},
        {"from": "microservices", "to": "micro_con", "label": "Tradeoffs", "style": "solid"},
    ]
)

# 4. Binary Search Tree Operation
BST_HIERARCHY_DIAGRAM = DiagramSpecification(
    title="Binary Search Tree Insertion Logic",
    diagram_type="hierarchy",
    description="Recursive subtree traversal preserving the invariant: Left < Root <= Right.",
    nodes=[
        {"id": "root", "label": "Root Node: 50", "description": "Entry point comparison", "highlight": False},
        {"id": "left_child", "label": "Left Child: 30", "description": "Keys < 50 navigate here", "highlight": False},
        {"id": "right_child", "label": "Right Child: 70", "description": "Keys >= 50 navigate here", "highlight": False},
        {"id": "left_left", "label": "Node: 20", "description": "Left leaf", "highlight": False},
        {"id": "target", "label": "Target Insert: 40", "description": "50 -> Left (30) -> Right (40)", "highlight": True},
        {"id": "right_right", "label": "Node: 85", "description": "Right leaf", "highlight": False},
    ],
    connections=[
        {"from": "root", "to": "left_child", "label": "val < 50", "style": "solid"},
        {"from": "root", "to": "right_child", "label": "val >= 50", "style": "solid"},
        {"from": "left_child", "to": "left_left", "label": "val < 30", "style": "solid"},
        {"from": "left_child", "to": "target", "label": "val > 30 (Inserted)", "style": "solid"},
        {"from": "right_child", "to": "right_right", "label": "val > 70", "style": "solid"},
    ]
)

DEMO_TEMPLATES = {
    "tcp": TCP_HANDSHAKE_DIAGRAM,
    "photosynthesis": PHOTOSYNTHESIS_DIAGRAM,
    "architecture": ARCHITECTURE_COMPARISON_DIAGRAM,
    "bst": BST_HIERARCHY_DIAGRAM,
}
