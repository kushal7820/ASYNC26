"""Pure Python standalone SVG diagram renderer for classroom projection."""

import html
import math
from typing import Dict, List, Tuple
from ai.diagram_schema import DiagramSpecification, DiagramNode, DiagramConnection


class SvgDiagramRenderer:
    """Renders structured educational diagram specifications into clean, scalable SVG."""

    def __init__(self, width: int = 800, height: int = 600):
        self.default_width = width
        self.default_height = height

    def render(self, spec: DiagramSpecification) -> str:
        """Translates DiagramSpecification into scalable SVG markup."""
        dtype = spec.diagram_type.lower()

        if dtype in ("sequence", "flowchart", "process"):
            return self._render_sequence_flow(spec)
        elif dtype == "cycle":
            return self._render_cycle(spec)
        elif dtype == "comparison":
            return self._render_comparison(spec)
        elif dtype == "hierarchy":
            return self._render_hierarchy(spec)
        elif dtype == "timeline":
            return self._render_timeline(spec)
        elif dtype == "architecture":
            return self._render_architecture(spec)
        else:
            # concept_map, labeled_diagram, and fallback
            return self._render_concept_map(spec)

    def _render_sequence_flow(self, spec: DiagramSpecification) -> str:
        """Render sequential flow with ordered steps, cards, and arrows."""
        nodes = spec.nodes
        count = max(1, len(nodes))
        card_w = 260
        card_h = 75
        gap = 35

        total_h = 130 + count * (card_h + gap) + 40
        width = 800

        center_x = width // 2
        node_positions: Dict[str, Tuple[int, int]] = {}

        svg_parts = [self._header(width, total_h, spec.title, spec.description, spec.diagram_type)]

        # Render cards vertically
        start_y = 120
        for i, node in enumerate(nodes):
            cx = center_x
            cy = start_y + i * (card_h + gap) + card_h // 2
            node_positions[node.id] = (cx, cy)

            step_label = f"STEP {i+1}"
            card_svg = self._draw_card(
                node=node,
                cx=cx,
                cy=cy,
                w=card_w,
                h=card_h,
                badge=step_label,
            )
            svg_parts.append(card_svg)

        # Render connections
        for conn in spec.connections:
            if conn.from_node in node_positions and conn.to_node in node_positions:
                x1, y1 = node_positions[conn.from_node]
                x2, y2 = node_positions[conn.to_node]
                # Draw vertical downward arrow
                svg_parts.append(
                    self._draw_arrow(
                        x1, y1 + card_h // 2,
                        x2, y2 - card_h // 2,
                        label=conn.label,
                        style=conn.style or "solid",
                    )
                )

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_cycle(self, spec: DiagramSpecification) -> str:
        """Render circular cyclic process with curved links."""
        nodes = spec.nodes
        count = max(1, len(nodes))
        width = 820
        height = 720
        cx = width // 2
        cy = 400
        radius = 210

        node_positions: Dict[str, Tuple[int, int]] = {}
        svg_parts = [self._header(width, height, spec.title, spec.description, spec.diagram_type)]

        # Central topic indicator
        svg_parts.append(f"""
        <circle cx="{cx}" cy="{cy}" r="55" fill="#1e293b" stroke="#334155" stroke-dasharray="4 4" stroke-width="2"/>
        <text x="{cx}" y="{cy - 5}" text-anchor="middle" fill="#94a3b8" font-size="12" font-weight="600" font-family="system-ui">RECURRING</text>
        <text x="{cx}" y="{cy + 15}" text-anchor="middle" fill="#38bdf8" font-size="14" font-weight="700" font-family="system-ui">CYCLE</text>
        """)

        # Place nodes around the circle
        for i, node in enumerate(nodes):
            angle = (2 * math.pi * i / count) - (math.pi / 2)
            nx = int(cx + radius * math.cos(angle))
            ny = int(cy + radius * math.sin(angle))
            node_positions[node.id] = (nx, ny)

            card = self._draw_card(node, nx, ny, w=170, h=65, badge=f"Phase {i+1}")
            svg_parts.append(card)

        # Draw connecting cyclic arcs
        for i in range(count):
            curr_id = nodes[i].id
            next_id = nodes[(i + 1) % count].id
            if curr_id in node_positions and next_id in node_positions:
                x1, y1 = node_positions[curr_id]
                x2, y2 = node_positions[next_id]

                # Match explicit connection label if available
                label = ""
                for conn in spec.connections:
                    if conn.from_node == curr_id and conn.to_node == next_id:
                        label = conn.label or ""
                        break

                mid_x = (x1 + x2) // 2 + int((cx - (x1 + x2) // 2) * -0.2)
                mid_y = (y1 + y2) // 2 + int((cy - (y1 + y2) // 2) * -0.2)
                svg_parts.append(f"""
                <path d="M {x1} {y1} Q {mid_x} {mid_y} {x2} {y2}" fill="none" stroke="#38bdf8" stroke-width="2" marker-end="url(#arrow)" stroke-dasharray="solid"/>
                """)
                if label:
                    svg_parts.append(f"""
                    <text x="{mid_x}" y="{mid_y - 6}" text-anchor="middle" fill="#94a3b8" font-size="11" font-family="system-ui">{html.escape(label)}</text>
                    """)

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_comparison(self, spec: DiagramSpecification) -> str:
        """Render side-by-side comparative column architecture."""
        nodes = spec.nodes
        width = 840
        left_nodes = []
        right_nodes = []

        for i, n in enumerate(nodes):
            if i % 2 == 0:
                left_nodes.append(n)
            else:
                right_nodes.append(n)

        rows = max(len(left_nodes), len(right_nodes), 1)
        card_h = 75
        gap = 25
        total_h = 140 + rows * (card_h + gap) + 40

        svg_parts = [self._header(width, total_h, spec.title, spec.description, spec.diagram_type)]

        # Column background panels
        col_w = 360
        left_cx = width // 4 + 10
        right_cx = 3 * (width // 4) - 10

        svg_parts.append(f"""
        <!-- Column 1 Background -->
        <rect x="{left_cx - col_w//2}" y="115" width="{col_w}" height="{total_h - 145}" rx="12" fill="#0f172a" stroke="#1e293b" stroke-width="1.5"/>
        <text x="{left_cx}" y="145" text-anchor="middle" fill="#38bdf8" font-size="14" font-weight="700" font-family="system-ui">APPROACH A</text>

        <!-- Column 2 Background -->
        <rect x="{right_cx - col_w//2}" y="115" width="{col_w}" height="{total_h - 145}" rx="12" fill="#0f172a" stroke="#1e293b" stroke-width="1.5"/>
        <text x="{right_cx}" y="145" text-anchor="middle" fill="#818cf8" font-size="14" font-weight="700" font-family="system-ui">APPROACH B</text>
        """)

        start_y = 175
        for i, node in enumerate(left_nodes):
            cy = start_y + i * (card_h + gap) + card_h // 2
            svg_parts.append(self._draw_card(node, left_cx, cy, w=col_w - 30, h=card_h))

        for i, node in enumerate(right_nodes):
            cy = start_y + i * (card_h + gap) + card_h // 2
            svg_parts.append(self._draw_card(node, right_cx, cy, w=col_w - 30, h=card_h))

        # Central VS marker
        vs_y = 120 + (total_h - 140) // 2
        svg_parts.append(f"""
        <circle cx="{width//2}" cy="{vs_y}" r="22" fill="#1e293b" stroke="#475569" stroke-width="2"/>
        <text x="{width//2}" y="{vs_y + 5}" text-anchor="middle" fill="#f8fafc" font-size="13" font-weight="800" font-family="system-ui">VS</text>
        """)

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_hierarchy(self, spec: DiagramSpecification) -> str:
        """Render tree or hierarchical branching graph."""
        nodes = spec.nodes
        width = 820
        height = 680
        svg_parts = [self._header(width, height, spec.title, spec.description, spec.diagram_type)]

        node_positions: Dict[str, Tuple[int, int]] = {}

        # If 1-6 nodes, structure in 3 levels (1 root -> 2 branches -> leaves)
        if len(nodes) >= 1:
            node_positions[nodes[0].id] = (width // 2, 170)
            svg_parts.append(self._draw_card(nodes[0], width // 2, 170, w=220, h=70, badge="ROOT"))

        level2_nodes = nodes[1:3]
        for i, n in enumerate(level2_nodes):
            x = (width // 3) * (i + 1)
            y = 310
            node_positions[n.id] = (x, y)
            svg_parts.append(self._draw_card(n, x, y, w=190, h=65, badge="BRANCH"))

        level3_nodes = nodes[3:]
        l3_count = max(1, len(level3_nodes))
        for i, n in enumerate(level3_nodes):
            x = int(width * (i + 1) / (l3_count + 1))
            y = 470
            node_positions[n.id] = (x, y)
            svg_parts.append(self._draw_card(n, x, y, w=170, h=65, badge="LEAF"))

        # Render connections
        for conn in spec.connections:
            if conn.from_node in node_positions and conn.to_node in node_positions:
                x1, y1 = node_positions[conn.from_node]
                x2, y2 = node_positions[conn.to_node]
                svg_parts.append(
                    self._draw_arrow(x1, y1 + 35, x2, y2 - 35, label=conn.label, style=conn.style or "solid")
                )

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_timeline(self, spec: DiagramSpecification) -> str:
        """Render chronological milestones."""
        nodes = spec.nodes
        count = max(1, len(nodes))
        width = 840
        height = 620
        svg_parts = [self._header(width, height, spec.title, spec.description, spec.diagram_type)]

        # Central timeline axis
        mid_y = 340
        svg_parts.append(f"""
        <line x1="80" y1="{mid_y}" x2="{width - 80}" y2="{mid_y}" stroke="#334155" stroke-width="4" stroke-linecap="round"/>
        """)

        step_x = (width - 200) / max(1, count - 1) if count > 1 else 0

        for i, node in enumerate(nodes):
            nx = int(100 + i * step_x)
            is_top = (i % 2 == 0)
            card_y = mid_y - 95 if is_top else mid_y + 95

            # Milestone node point
            color = "#38bdf8" if node.highlight else "#818cf8"
            svg_parts.append(f"""
            <circle cx="{nx}" cy="{mid_y}" r="8" fill="{color}" stroke="#0f172a" stroke-width="3"/>
            <line x1="{nx}" y1="{mid_y}" x2="{nx}" y2="{card_y + (35 if is_top else -35)}" stroke="#475569" stroke-width="2" stroke-dasharray="3 3"/>
            """)

            svg_parts.append(
                self._draw_card(node, nx, card_y, w=180, h=65, badge=f"Phase {i+1}")
            )

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_architecture(self, spec: DiagramSpecification) -> str:
        """Render layered software architecture or system topology."""
        nodes = spec.nodes
        width = 820
        height = 680
        svg_parts = [self._header(width, height, spec.title, spec.description, spec.diagram_type)]

        card_w = 200
        card_h = 70
        cols = 3
        start_x = width // 2
        start_y = 160

        node_positions: Dict[str, Tuple[int, int]] = {}
        for i, node in enumerate(nodes):
            row = i // cols
            col = i % cols
            x = (width // 4) * (col + 1)
            y = start_y + row * 120
            node_positions[node.id] = (x, y)
            svg_parts.append(self._draw_card(node, x, y, w=card_w, h=card_h))

        for conn in spec.connections:
            if conn.from_node in node_positions and conn.to_node in node_positions:
                x1, y1 = node_positions[conn.from_node]
                x2, y2 = node_positions[conn.to_node]
                svg_parts.append(
                    self._draw_arrow(x1, y1 + card_h//2, x2, y2 - card_h//2, label=conn.label, style=conn.style or "solid")
                )

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _render_concept_map(self, spec: DiagramSpecification) -> str:
        """Render concept map with hub-and-spoke or networked nodes."""
        nodes = spec.nodes
        count = len(nodes)
        width = 820
        height = 680
        cx = width // 2
        cy = 380

        svg_parts = [self._header(width, height, spec.title, spec.description, spec.diagram_type)]
        node_positions: Dict[str, Tuple[int, int]] = {}

        if count > 0:
            # Hub node in center
            hub = nodes[0]
            node_positions[hub.id] = (cx, cy)
            svg_parts.append(self._draw_card(hub, cx, cy, w=220, h=75, badge="CORE CONCEPT"))

            # Peripheral concepts in circle around hub
            peripherals = nodes[1:]
            p_count = max(1, len(peripherals))
            radius = 210

            for i, node in enumerate(peripherals):
                angle = (2 * math.pi * i / p_count) - (math.pi / 2)
                nx = int(cx + radius * math.cos(angle))
                ny = int(cy + radius * math.sin(angle))
                node_positions[node.id] = (nx, ny)
                svg_parts.append(self._draw_card(node, nx, ny, w=175, h=65))

        # Connections
        for conn in spec.connections:
            if conn.from_node in node_positions and conn.to_node in node_positions:
                x1, y1 = node_positions[conn.from_node]
                x2, y2 = node_positions[conn.to_node]
                svg_parts.append(
                    self._draw_arrow(x1, y1, x2, y2, label=conn.label, style=conn.style or "solid")
                )

        svg_parts.append("</svg>")
        return "\n".join(svg_parts)

    def _header(self, width: int, height: int, title: str, description: str = None, dtype: str = "diagram") -> str:
        """Generate consistent educational dark-theme SVG header."""
        escaped_title = html.escape(title)
        escaped_desc = html.escape(description or "")
        dtype_badge = html.escape(dtype.upper().replace("_", " "))

        return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" width="100%" height="100%" style="background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
  <defs>
    <!-- Arrowhead Marker -->
    <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 10 5 L 0 9 z" fill="#38bdf8"/>
    </marker>
    <!-- Drop Shadow Filter -->
    <filter id="card-shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000000" flood-opacity="0.4"/>
    </filter>
    <!-- Highlight Glow -->
    <filter id="focal-glow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="0" stdDeviation="8" flood-color="#38bdf8" flood-opacity="0.35"/>
    </filter>
  </defs>

  <!-- Background Base -->
  <rect width="{width}" height="{height}" fill="#0b0f19"/>
  <rect width="{width}" height="{height}" fill="none" stroke="#1e293b" stroke-width="2"/>

  <!-- Educational Header Banner -->
  <g transform="translate(30, 25)">
    <rect x="0" y="0" width="110" height="22" rx="4" fill="#0369a1" fill-opacity="0.3"/>
    <text x="55" y="15" text-anchor="middle" fill="#38bdf8" font-size="11" font-weight="700" letter-spacing="1">{dtype_badge}</text>
    <text x="0" y="44" fill="#f8fafc" font-size="20" font-weight="700">{escaped_title}</text>
    <text x="0" y="65" fill="#94a3b8" font-size="13" font-weight="400">{escaped_desc}</text>
  </g>
  <line x1="30" y1="100" x2="{width - 30}" y2="100" stroke="#1e293b" stroke-width="1.5"/>
"""

    def _draw_card(
        self,
        node: DiagramNode,
        cx: int,
        cy: int,
        w: int = 200,
        h: int = 70,
        badge: str = None,
    ) -> str:
        """Render an individual node card."""
        x = cx - w // 2
        y = cy - h // 2
        is_highlight = bool(node.highlight)

        border_color = "#38bdf8" if is_highlight else "#334155"
        border_width = "2.5" if is_highlight else "1.5"
        bg_fill = "#1e293b" if is_highlight else "#0f172a"
        filter_attr = 'filter="url(#focal-glow)"' if is_highlight else 'filter="url(#card-shadow)"'

        label_escaped = html.escape(node.label)
        desc_escaped = html.escape(node.description or "")

        parts = [f"""
        <!-- Node Card: {node.id} -->
        <g {filter_attr}>
          <rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{bg_fill}" stroke="{border_color}" stroke-width="{border_width}"/>
        """]

        if badge:
            badge_color = "#0284c7" if is_highlight else "#475569"
            parts.append(f"""
            <rect x="{x + 8}" y="{y + 8}" width="60" height="15" rx="3" fill="{badge_color}"/>
            <text x="{x + 38}" y="{y + 19}" text-anchor="middle" fill="#f8fafc" font-size="9" font-weight="700" letter-spacing="0.5">{html.escape(badge)}</text>
            """)

        title_y = y + 36 if badge else y + 28
        parts.append(f"""
          <text x="{x + 12}" y="{title_y}" fill="#f8fafc" font-size="13" font-weight="600">{label_escaped}</text>
        """)

        if desc_escaped:
            # truncate long description to fit card neatly
            truncated_desc = desc_escaped[:36] + "..." if len(desc_escaped) > 38 else desc_escaped
            parts.append(f"""
          <text x="{x + 12}" y="{title_y + 18}" fill="#94a3b8" font-size="11" font-weight="400">{truncated_desc}</text>
            """)

        parts.append("</g>")
        return "".join(parts)

    def _draw_arrow(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        label: str = None,
        style: str = "solid",
    ) -> str:
        """Render a connecting arrow line with label."""
        dash = "stroke-dasharray=\"4 4\"" if style == "dashed" else ("stroke-dasharray=\"2 2\"" if style == "dotted" else "")
        label_escaped = html.escape(label) if label else ""

        mid_x = (x1 + x2) // 2
        mid_y = (y1 + y2) // 2

        line_svg = f"""
        <line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#38bdf8" stroke-width="2" {dash} marker-end="url(#arrow)"/>
        """

        if label_escaped:
            line_svg += f"""
        <rect x="{mid_x - 45}" y="{mid_y - 12}" width="90" height="20" rx="4" fill="#0b0f19" fill-opacity="0.85" stroke="#334155" stroke-width="0.8"/>
        <text x="{mid_x}" y="{mid_y + 2}" text-anchor="middle" fill="#38bdf8" font-size="10" font-weight="600" font-family="system-ui">{label_escaped}</text>
            """

        return line_svg
