"""Main diagram rendering coordinator."""

from typing import Union
from ai.diagram_schema import (
    DiagramSpecification,
    validate_and_parse_diagram_json,
)
from diagram.svg_renderer import SvgDiagramRenderer
from utils.logger import setup_logger

logger = setup_logger()


class DiagramRenderer:
    """Coordinates parsing, validation, and SVG generation for visualizations."""

    def __init__(self):
        self._svg_engine = SvgDiagramRenderer()

    def render_spec(self, spec: DiagramSpecification) -> str:
        """Render a validated DiagramSpecification into SVG."""
        logger.info(f"Rendering SVG diagram: '{spec.title}' (type: {spec.diagram_type})")
        return self._svg_engine.render(spec)

    def render_json(self, raw_json: Union[str, dict]) -> str:
        """Parse raw JSON and generate SVG."""
        if isinstance(raw_json, dict):
            spec = DiagramSpecification.model_validate(raw_json)
        else:
            spec = validate_and_parse_diagram_json(raw_json)
        return self.render_spec(spec)

    def wrap_svg_in_html(self, svg_content: str, title: str = "ClassVision Diagram") -> str:
        """Wrap SVG in a responsive HTML document for web or PySide WebEngine display."""
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>{title}</title>
  <style>
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      background-color: #0b0f19;
      color: #f8fafc;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      overflow: hidden;
      padding: 12px;
    }}
    .svg-container {{
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }}
    svg {{
      max-width: 100%;
      max-height: 98vh;
      border-radius: 8px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
    }}
  </style>
</head>
<body>
  <div class="svg-container">
    {svg_content}
  </div>
</body>
</html>"""
