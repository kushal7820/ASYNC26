"""Rolling transcript buffer and speech transcriber."""

import time
from collections import deque
from dataclasses import dataclass
from typing import List, Optional, Tuple
from utils.logger import setup_logger

logger = setup_logger()

try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None


@dataclass
class TranscriptSegment:
    """A segment of transcribed speech with a timestamp."""

    timestamp: float
    text: str


class RollingTranscriptBuffer:
    """Maintains approximately the last N seconds (default: 45s) of teacher explanation."""

    def __init__(self, max_duration: float = 45.0):
        self.max_duration = max_duration
        self._segments: deque[TranscriptSegment] = deque()

    def add_segment(self, text: str, timestamp: Optional[float] = None) -> None:
        """Add a newly transcribed text segment to the rolling buffer."""
        cleaned = text.strip()
        if not cleaned:
            return

        now = timestamp if timestamp is not None else time.time()
        self._segments.append(TranscriptSegment(timestamp=now, text=cleaned))
        self._prune(now)

    def _prune(self, current_time: float) -> None:
        """Remove segments older than max_duration."""
        cutoff = current_time - self.max_duration
        while self._segments and self._segments[0].timestamp < cutoff:
            self._segments.popleft()

    def get_recent_text(self, current_time: Optional[float] = None) -> str:
        """Retrieve the concatenated transcript of the recent explanation."""
        now = current_time if current_time is not None else time.time()
        self._prune(now)
        return " ".join(seg.text for seg in self._segments).strip()

    def get_segments(self, current_time: Optional[float] = None) -> List[TranscriptSegment]:
        """Return list of recent segments."""
        now = current_time if current_time is not None else time.time()
        self._prune(now)
        return list(self._segments)

    def is_empty(self) -> bool:
        """Check if buffer has any recent text."""
        return len(self._segments) == 0

    def clear(self) -> None:
        """Clear all stored transcript segments."""
        self._segments.clear()


class Transcriber:
    """Local speech transcriber using faster-whisper with graceful fallback."""

    def __init__(self, model_size: str = "base"):
        self.model_size = model_size
        self._model = None
        self._is_available = WhisperModel is not None

    def initialize(self) -> bool:
        """Initialize the whisper model."""
        if not self._is_available:
            logger.warning(
                "faster-whisper is not installed. Speech transcription will operate in fallback mode. F9 remains fully functional."
            )
            return False

        try:
            logger.info(f"Loading local Whisper model: {self.model_size} (CPU/INT8)...")
            self._model = WhisperModel(
                self.model_size, device="cpu", compute_type="int8"
            )
            logger.info("Local Whisper model loaded successfully.")
            return True
        except Exception as e:
            logger.error(f"Failed to load Whisper model: {e}")
            self._is_available = False
            return False

    @property
    def is_available(self) -> bool:
        return self._is_available and self._model is not None

    def transcribe_audio_file(self, audio_path: str) -> str:
        """Transcribe an audio file locally without transmitting voice data to the cloud."""
        if not self.is_available:
            return ""

        try:
            segments, _ = self._model.transcribe(
                audio_path,
                beam_size=3,
                language="en",
                vad_filter=True,
            )
            text = " ".join(segment.text.strip() for segment in segments)
            return text.strip()
        except Exception as e:
            logger.error(f"Transcription error: {e}")
            return ""
