"""Voice trigger phrase detector with cooldown and debouncing."""

import re
import time
from typing import List, Optional, Set
from utils.logger import setup_logger

logger = setup_logger()

DEFAULT_TRIGGERS = [
    "visualize this",
    "visualize this line",
    "visualize this concept",
    "visualize the slide",
    "visualize the whole page",
    "show me a diagram",
    "draw this",
]


class TriggerDetector:
    """Detects spoken trigger commands with debounce and cooldown mechanisms."""

    def __init__(
        self,
        trigger_phrases: Optional[List[str]] = None,
        cooldown_seconds: float = 6.0,
    ):
        raw_phrases = trigger_phrases or DEFAULT_TRIGGERS
        # Sort by length descending so more specific phrases ("visualize this line") match before ("visualize this")
        self.trigger_phrases = sorted(
            [self._normalize(p) for p in raw_phrases],
            key=len,
            reverse=True,
        )
        self.cooldown_seconds = cooldown_seconds
        self._last_trigger_time: float = 0.0
        self._last_triggered_text: str = ""

    def _normalize(self, text: str) -> str:
        """Strip punctuation and normalize spacing for robust matching."""
        lowered = text.lower()
        cleaned = re.sub(r"[^\w\s]", " ", lowered)
        return " ".join(cleaned.split())

    def check_text(self, text: str, current_time: Optional[float] = None) -> Optional[str]:
        """Check if incoming speech contains any trigger phrase.

        Returns the matched trigger phrase if detected and not in cooldown,
        or None otherwise.
        """
        if not text:
            return None

        now = current_time if current_time is not None else time.time()

        # Check cooldown
        if (now - self._last_trigger_time) < self.cooldown_seconds:
            return None

        normalized = self._normalize(text)

        # Prevent duplicate firing on the identical transcript buffer
        if normalized == self._last_triggered_text and (now - self._last_trigger_time) < 15.0:
            return None

        for trigger in self.trigger_phrases:
            if trigger in normalized:
                self._last_trigger_time = now
                self._last_triggered_text = normalized
                logger.info(f"Voice trigger detected: '{trigger}' in explanation")
                return trigger

        return None

    def reset_cooldown(self) -> None:
        """Manually reset the cooldown period."""
        self._last_trigger_time = 0.0
        self._last_triggered_text = ""
