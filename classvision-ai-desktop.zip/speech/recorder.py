"""Local microphone audio recorder for real-time speech processing."""

import threading
import time
from typing import Callable, Optional
from utils.logger import setup_logger

logger = setup_logger()


class AudioRecorder:
    """Manages local microphone capture in a background thread."""

    def __init__(self, sample_rate: int = 16000, chunk_duration: float = 3.0):
        self.sample_rate = sample_rate
        self.chunk_duration = chunk_duration
        self._is_recording = False
        self._thread: Optional[threading.Thread] = None
        self._callback: Optional[Callable[[str], None]] = None

    def start(self, on_speech_chunk: Optional[Callable[[str], None]] = None) -> bool:
        """Start background microphone recording."""
        if self._is_recording:
            return True

        self._callback = on_speech_chunk
        self._is_recording = True

        logger.info("Audio recorder session initiated.")
        return True

    def stop(self) -> None:
        """Stop microphone recording cleanly."""
        self._is_recording = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        self._thread = None
        logger.info("Audio recorder session stopped.")

    @property
    def is_recording(self) -> bool:
        return self._is_recording
