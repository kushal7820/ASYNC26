"""ClassVision AI — AI-Powered Live Teaching Visualizer.

Main entry point and system verification check.
"""

import sys
import importlib.util
from typing import Dict, Tuple

from config.settings import settings
from utils.logger import setup_logger

logger = setup_logger()


def run_first_run_check() -> Tuple[bool, Dict[str, Tuple[bool, str]]]:
    """Verify system readiness before launching the application.

    Checks:
    - Python version (3.10+)
    - Screen capture (mss)
    - Keyboard shortcut hooks (pynput)
    - AI API configuration
    - Microphone & transcription availability (faster-whisper)
    """
    results: Dict[str, Tuple[bool, str]] = {}

    # 1. Python version
    py_ver = sys.version_info
    py_ok = py_ver >= (3, 10)
    results["Python version"] = (
        py_ok,
        f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}"
        if py_ok
        else f"Requires Python 3.10+, found {py_ver.major}.{py_ver.minor}",
    )

    # 2. Screen capture (mss)
    has_mss = importlib.util.find_spec("mss") is not None
    results["Screen capture"] = (
        has_mss,
        "mss available" if has_mss else "mss missing; install via pip install mss",
    )

    # 3. Keyboard shortcut (pynput)
    has_pynput = importlib.util.find_spec("pynput") is not None
    results["Keyboard shortcut (F9)"] = (
        has_pynput,
        "pynput available"
        if has_pynput
        else "pynput missing; install via pip install pynput",
    )

    # 4. AI configuration
    has_api_key = bool(settings.ai_api_key)
    results["AI configuration"] = (
        has_api_key,
        f"Configured with {settings.ai_model}"
        if has_api_key
        else "AI_API_KEY missing in .env (Demo mode available)",
    )

    # 5. Microphone & Whisper
    has_whisper = importlib.util.find_spec("faster_whisper") is not None
    results["Microphone & Whisper"] = (
        has_whisper,
        "faster-whisper available for local private STT"
        if has_whisper
        else "faster-whisper not installed; F9 manual trigger fully supported",
    )

    all_critical_ok = py_ok
    return all_critical_ok, results


def print_system_check(results: Dict[str, Tuple[bool, str]]) -> None:
    """Print clean diagnostic banner to console."""
    print("=" * 60)
    print("   ClassVision AI — System Diagnostic Check")
    print("=" * 60)
    for check_name, (ok, detail) in results.items():
        symbol = "✓" if ok else "⚠"
        print(f"  {symbol} {check_name:<26} : {detail}")
    print("=" * 60)


def main():
    """Launch ClassVision AI desktop application."""
    logger.info("Application started.")

    # Execute system check
    critical_ok, check_results = run_first_run_check()
    print_system_check(check_results)

    # Attempt PySide6 UI Launch
    try:
        from PySide6.QtWidgets import QApplication
        from ui.main_window import MainWindow

        app = QApplication(sys.argv)
        app.setApplicationName("ClassVision AI")

        window = MainWindow()
        window.show()

        sys.exit(app.exec())
    except ImportError as e:
        logger.warning(
            f"PySide6 GUI could not be initialized in this console environment: {e}\n"
            "To test the core pipeline in console or headless mode, run tests: python run_tests.py"
        )


if __name__ == "__main__":
    main()
