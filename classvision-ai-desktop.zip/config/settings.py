"""Configuration settings for ClassVision AI."""

import os
from dataclasses import dataclass, field
from typing import List
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Settings:
    """Application configuration settings."""

    # AI Configuration
    ai_api_key: str = field(
        default_factory=lambda: os.getenv("AI_API_KEY", os.getenv("GEMINI_API_KEY", ""))
    )
    ai_model: str = field(
        default_factory=lambda: os.getenv("AI_MODEL", "gemini-2.5-flash")
    )

    # Speech Configuration
    whisper_model: str = field(
        default_factory=lambda: os.getenv("WHISPER_MODEL", "base")
    )
    transcript_duration: float = float(
        os.getenv("TRANSCRIPT_DURATION", "45.0")
    )  # seconds
    trigger_cooldown: float = 6.0  # seconds between automatic triggers

    # Trigger Phrases
    trigger_phrases: List[str] = field(
        default_factory=lambda: [
            "visualize this",
            "visualize this line",
            "visualize this concept",
            "visualize the slide",
            "visualize the whole page",
            "show me a diagram",
            "draw this",
        ]
    )

    # Hotkey Configuration
    hotkey: str = "F9"

    # Overlay Window Configuration
    overlay_width: int = 500
    overlay_height: int = 680
    overlay_position: str = "right"  # "right", "left", "float"

    # Behavior
    demo_mode: bool = False
    save_screenshot_history: bool = False


# Global singleton instance
settings = Settings()
