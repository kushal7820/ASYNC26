"""Visualization pipeline orchestrator."""

import time
import threading
from typing import Callable, Optional
from pathlib import Path

from core.state import (
    AppSessionState,
    AppStatus,
    VisualizationContext,
)
from capture.screen_capture import ScreenCapturer
from capture.cursor_tracker import get_current_cursor_context
from core.session import SessionManager
from ai.client import MultimodalAIClient
from diagram.renderer import DiagramRenderer
from utils.logger import setup_logger

logger = setup_logger()


class VisualizationOrchestrator:
    """Coordinates screen capture, cursor context, transcript buffer, AI generation, and SVG rendering."""

    def __init__(
        self,
        session_manager: SessionManager,
        on_state_changed: Optional[Callable[[AppSessionState], None]] = None,
        on_visualization_ready: Optional[Callable[[VisualizationContext], None]] = None,
        on_error: Optional[Callable[[str], None]] = None,
    ):
        self.session_manager = session_manager
        self.on_state_changed = on_state_changed
        self.on_visualization_ready = on_visualization_ready
        self.on_error = on_error

        self.state = AppSessionState()
        self.capturer = ScreenCapturer()
        self.ai_client = MultimodalAIClient()
        self.diagram_renderer = DiagramRenderer()
        self._lock = threading.Lock()

    def trigger_visualization(
        self,
        source: str = "F9",
        is_regenerate: bool = False,
        extra_instruction: str = "",
        demo_topic: Optional[str] = None,
    ) -> bool:
        """Trigger visualization pipeline in background thread.

        Prevents duplicate overlapping generation requests.
        """
        with self._lock:
            if self.state.is_generating:
                logger.warning("Visualization request ignored: Generation already in progress.")
                return False

            self.state.is_generating = True
            self.state.status = AppStatus.GENERATING
            self._notify_state()

        # Run pipeline in background thread to never block UI
        worker_thread = threading.Thread(
            target=self._execute_pipeline,
            args=(source, is_regenerate, extra_instruction, demo_topic),
            daemon=True,
        )
        worker_thread.start()
        return True

    def _execute_pipeline(
        self,
        source: str,
        is_regenerate: bool,
        extra_instruction: str,
        demo_topic: Optional[str],
    ) -> None:
        """Execute the sequential pipeline steps."""
        logger.info(f"Visualization triggered via {source} (Regenerate: {is_regenerate})")
        context = VisualizationContext(timestamp=time.time(), trigger_source=source)

        try:
            # 1. Capture Screen
            screenshot_path = self.capturer.capture()
            context.screenshot_path = screenshot_path
            screen_w, screen_h = self.capturer.last_dimensions

            # 2. Get Cursor Position
            cursor_ctx = get_current_cursor_context(screen_w, screen_h)
            context.cursor = cursor_ctx
            cursor_hint = cursor_ctx.to_hint_string()

            # 3. Get Recent Transcript
            transcript = self.session_manager.get_recent_transcript()
            context.transcript = transcript

            # 4. Multimodal AI Analysis
            logger.info("Sending slide, speech transcript, and cursor context to AI...")
            spec = self.ai_client.generate_diagram(
                image_path_or_bytes=screenshot_path,
                transcript=transcript,
                cursor_hint=cursor_hint,
                is_regenerate=is_regenerate,
                extra_instruction=extra_instruction,
                demo_topic=demo_topic,
            )
            context.diagram_spec = spec

            # 5. Render SVG
            svg_content = self.diagram_renderer.render_spec(spec)
            context.svg_content = svg_content

            # 6. Update Session State
            with self._lock:
                self.state.last_context = context
                self.state.last_error = None
                self.state.is_generating = False
                self.state.status = (
                    AppStatus.LISTENING if self.session_manager.is_active else AppStatus.READY
                )
                if is_regenerate:
                    self.state.regenerate_count += 1
                else:
                    self.state.regenerate_count = 0
                self._notify_state()

            # 7. Notify UI & Overlay
            if self.on_visualization_ready:
                self.on_visualization_ready(context)

            logger.info(f"Visualization successfully generated: '{spec.title}'")

        except Exception as e:
            err_msg = str(e)
            logger.error(f"Visualization pipeline failed: {err_msg}")
            context.error_message = err_msg

            with self._lock:
                self.state.last_error = err_msg
                self.state.is_generating = False
                self.state.status = AppStatus.ERROR
                self._notify_state()

            if self.on_error:
                self.on_error(err_msg)

        finally:
            # Clean up temporary screenshot if history is disabled
            self.capturer.cleanup()

    def regenerate(self) -> bool:
        """Regenerate the current diagram with the same context."""
        if self.state.regenerate_count >= 5:
            logger.warning("Maximum regeneration attempts reached.")
            return False
        return self.trigger_visualization(source="Regenerate", is_regenerate=True)

    def _notify_state(self) -> None:
        """Trigger state update callback."""
        if self.on_state_changed:
            self.on_state_changed(self.state)
