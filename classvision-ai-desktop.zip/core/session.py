"""Teaching session manager for audio capture, hotkeys, and buffer management."""

import time
import threading
from typing import Callable, Optional
from config.settings import settings
from speech.recorder import AudioRecorder
from speech.transcriber import RollingTranscriptBuffer, Transcriber
from speech.trigger_detector import TriggerDetector
from utils.logger import setup_logger

logger = setup_logger()

try:
    from pynput import keyboard
except ImportError:
    keyboard = None


class SessionManager:
    """Manages background threads, global hotkeys, speech buffers, and triggers."""

    def __init__(
        self,
        on_trigger_visualize: Optional[Callable[[str], None]] = None,
        on_transcript_updated: Optional[Callable[[str], None]] = None,
    ):
        self.on_trigger_visualize = on_trigger_visualize
        self.on_transcript_updated = on_transcript_updated

        self.transcript_buffer = RollingTranscriptBuffer(
            max_duration=settings.transcript_duration
        )
        self.trigger_detector = TriggerDetector(
            trigger_phrases=settings.trigger_phrases,
            cooldown_seconds=settings.trigger_cooldown,
        )
        self.recorder = AudioRecorder()
        self.transcriber = Transcriber(model_size=settings.whisper_model)

        self._hotkey_listener = None
        self._is_active = False

    def start_session(self) -> bool:
        """Start the teaching session."""
        if self._is_active:
            return True

        self._is_active = True
        logger.info("Session started.")

        # 1. Start audio recorder
        self.recorder.start(on_speech_chunk=self._on_audio_chunk)

        # 2. Register global hotkey (F9)
        self._register_hotkey()

        return True

    def stop_session(self) -> None:
        """Stop background processing cleanly with no orphan threads."""
        if not self._is_active:
            return

        self._is_active = False
        self.recorder.stop()
        self._unregister_hotkey()
        logger.info("Session stopped cleanly.")

    def add_transcript_text(self, text: str) -> None:
        """Feed newly transcribed text into buffer and check for voice triggers."""
        if not text.strip():
            return

        self.transcript_buffer.add_segment(text)
        recent_text = self.transcript_buffer.get_recent_text()

        if self.on_transcript_updated:
            self.on_transcript_updated(recent_text)

        # Check for voice trigger phrase
        matched_trigger = self.trigger_detector.check_text(text)
        if matched_trigger and self.on_trigger_visualize:
            logger.info(f"Voice trigger invoked: '{matched_trigger}'")
            self.on_trigger_visualize(f"voice: {matched_trigger}")

    def get_recent_transcript(self) -> str:
        """Retrieve the concatenated transcript from the last ~45 seconds."""
        return self.transcript_buffer.get_recent_text()

    def _on_audio_chunk(self, chunk_text: str) -> None:
        """Callback from audio processing thread."""
        self.add_transcript_text(chunk_text)

    def _register_hotkey(self) -> None:
        """Register the F9 global keyboard shortcut listener."""
        if keyboard is None:
            logger.warning("pynput not available. Global hotkey disabled in this environment.")
            return

        try:
            def on_press(key):
                try:
                    if key == keyboard.Key.f9:
                        logger.info("F9 hotkey pressed.")
                        if self.on_trigger_visualize:
                            self.on_trigger_visualize("F9 hotkey")
                except Exception as e:
                    logger.error(f"Error handling key press: {e}")

            self._hotkey_listener = keyboard.Listener(on_press=on_press)
            self._hotkey_listener.daemon = True
            self._hotkey_listener.start()
            logger.info("Global F9 hotkey registered.")
        except Exception as e:
            logger.warning(f"Could not register global hotkey (display server required): {e}")

    def _unregister_hotkey(self) -> None:
        """Stop hotkey listener."""
        if self._hotkey_listener:
            try:
                self._hotkey_listener.stop()
            except Exception:
                pass
            self._hotkey_listener = None

    @property
    def is_active(self) -> bool:
        return self._is_active
