"""State management dataclasses and enums for ClassVision AI."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List
from pathlib import Path

from capture.cursor_tracker import CursorContext
from ai.diagram_schema import DiagramSpecification


class AppStatus(str, Enum):
    """Application running status."""

    READY = "Ready"
    LISTENING = "Listening"
    GENERATING = "Generating"
    ERROR = "Error"


@dataclass
class VisualizationContext:
    """Snapshot of presentation context when visualization is triggered."""

    timestamp: float
    screenshot_path: Optional[Path] = None
    transcript: str = ""
    cursor: Optional[CursorContext] = None
    trigger_source: str = "F9"  # "F9", "voice", "manual"
    diagram_spec: Optional[DiagramSpecification] = None
    svg_content: Optional[str] = None
    error_message: Optional[str] = None


@dataclass
class AppSessionState:
    """Live state of the active teaching session."""

    status: AppStatus = AppStatus.READY
    is_session_active: bool = False
    is_microphone_active: bool = False
    is_generating: bool = False
    current_transcript: str = ""
    last_context: Optional[VisualizationContext] = None
    last_error: Optional[str] = None
    regenerate_count: int = 0
