"""Convenience root runner for ClassVision AI unit tests."""

import subprocess
import sys
from pathlib import Path

if __name__ == "__main__":
    test_script = Path(__file__).parent / "tests" / "run_tests.py"
    res = subprocess.run([sys.executable, str(test_script)])
    sys.exit(res.returncode)
