"""Screen capture implementation using mss with safe cleanup."""

import os
from pathlib import Path
from typing import Optional, Tuple
from utils.paths import TEMP_SCREENSHOT
from utils.logger import setup_logger

logger = setup_logger()

try:
    import mss
    import mss.tools
except ImportError:
    mss = None


class ScreenCapturer:
    """Captures the current PowerPoint screen or primary monitor display."""

    def __init__(self, temp_path: Path = TEMP_SCREENSHOT):
        self.temp_path = temp_path
        self._last_dimensions: Tuple[int, int] = (1920, 1080)

    @property
    def last_dimensions(self) -> Tuple[int, int]:
        """Returns the dimensions (width, height) of the last captured screenshot."""
        return self._last_dimensions

    def capture(self, monitor_index: int = 1) -> Optional[Path]:
        """Capture screenshot to the temporary location.

        Returns the path to the saved image file, or None on failure.
        """
        if mss is None:
            logger.warning("mss package not available. Generating demo slide capture.")
            return self._generate_fallback_slide()

        try:
            with mss.mss() as sct:
                # monitor_index 1 is typically primary monitor
                monitors = sct.monitors
                target_monitor = (
                    monitors[monitor_index]
                    if len(monitors) > monitor_index
                    else monitors[0]
                )

                sct_img = sct.grab(target_monitor)
                self._last_dimensions = (sct_img.width, sct_img.height)

                # Ensure target directory exists
                self.temp_path.parent.mkdir(parents=True, exist_ok=True)

                # Save temporary screenshot
                mss.tools.to_png(sct_img.rgb, sct_img.size, output=str(self.temp_path))
                logger.info(
                    f"Screenshot captured: {sct_img.width}x{sct_img.height} -> {self.temp_path.name}"
                )
                return self.temp_path

        except Exception as e:
            logger.error(f"Screen capture failed: {e}")
            return self._generate_fallback_slide()

    def _generate_fallback_slide(self) -> Path:
        """Generates a sample educational slide image for headless / fallback testing."""
        try:
            from PIL import Image, ImageDraw

            img = Image.new("RGB", (1280, 720), color=(15, 23, 42))
            draw = ImageDraw.Draw(img)
            # Draw header
            draw.text((80, 80), "COMPUTER NETWORKING 101", fill=(148, 163, 184))
            draw.text(
                (80, 130), "TCP Handshake & Transport Layer", fill=(248, 250, 252)
            )
            # Draw sample slide boxes
            draw.rectangle(
                [100, 260, 450, 480], outline=(56, 189, 248), width=3, fill=(30, 41, 59)
            )
            draw.text((120, 290), "CLIENT (Initiator)", fill=(255, 255, 255))
            draw.text(
                (120, 340), "• Generates random ISN\n• Sends SYN packet\n• Waits for SYN-ACK", fill=(203, 213, 225)
            )

            draw.rectangle(
                [830, 260, 1180, 480], outline=(129, 140, 248), width=3, fill=(30, 41, 59)
            )
            draw.text((850, 290), "SERVER (Listener)", fill=(255, 255, 255))
            draw.text(
                (850, 340), "• Listens on port\n• Allocates TCB buffer\n• Replies SYN-ACK", fill=(203, 213, 225)
            )

            self.temp_path.parent.mkdir(parents=True, exist_ok=True)
            img.save(self.temp_path)
            self._last_dimensions = (1280, 720)
            return self.temp_path
        except Exception as e:
            logger.error(f"Fallback slide creation failed: {e}")
            return self.temp_path

    def cleanup(self) -> None:
        """Remove temporary screenshot to preserve privacy."""
        try:
            if self.temp_path.exists():
                os.remove(self.temp_path)
                logger.debug("Temporary screenshot cleaned up.")
        except Exception as e:
            logger.warning(f"Could not remove temp screenshot: {e}")
