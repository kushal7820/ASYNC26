"""Cursor position tracker and contextual hint generator."""

from dataclasses import dataclass
from typing import Tuple, Optional

try:
    import pyautogui
except ImportError:
    pyautogui = None


@dataclass
class CursorContext:
    """Cursor position context relative to the captured slide/screen."""

    screen_x: int
    screen_y: int
    screen_width: int
    screen_height: int
    rel_x: float  # 0.0 to 1.0
    rel_y: float  # 0.0 to 1.0
    rel_x_pct: int  # 0 to 100
    rel_y_pct: int  # 0 to 100

    def to_hint_string(self) -> str:
        """Returns the prompt hint string for the AI model."""
        return (
            f"The teacher's cursor is approximately at {self.rel_x_pct}% width and "
            f"{self.rel_y_pct}% height of the screenshot.\n"
            "Use this location as a hint for the part of the slide currently being discussed."
        )


def calculate_relative_cursor(
    cursor_x: int, cursor_y: int, screen_width: int, screen_height: int
) -> CursorContext:
    """Calculate relative coordinates clamped between 0.0 and 1.0.

    Ensures zero division protection and clean percentage calculations.
    """
    width = max(1, screen_width)
    height = max(1, screen_height)

    # Clamp coordinates to screen boundaries
    clamped_x = max(0, min(cursor_x, width))
    clamped_y = max(0, min(cursor_y, height))

    rel_x = round(clamped_x / width, 4)
    rel_y = round(clamped_y / height, 4)
    rel_x_pct = int(round(rel_x * 100))
    rel_y_pct = int(round(rel_y * 100))

    return CursorContext(
        screen_x=cursor_x,
        screen_y=cursor_y,
        screen_width=width,
        screen_height=height,
        rel_x=rel_x,
        rel_y=rel_y,
        rel_x_pct=rel_x_pct,
        rel_y_pct=rel_y_pct,
    )


def get_current_cursor_context(
    screen_width: int = 1920, screen_height: int = 1080
) -> CursorContext:
    """Capture the current physical mouse cursor position."""
    if pyautogui is not None:
        try:
            x, y = pyautogui.position()
            return calculate_relative_cursor(x, y, screen_width, screen_height)
        except Exception:
            pass

    # Default fallback to center of screen
    return calculate_relative_cursor(
        screen_width // 2, screen_height // 2, screen_width, screen_height
    )
