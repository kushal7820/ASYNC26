"""Unit tests for standalone SVG diagram generation."""

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai.diagram_schema import DiagramSpecification
from diagram.svg_renderer import SvgDiagramRenderer
from diagram.renderer import DiagramRenderer


class TestSvgRenderer(unittest.TestCase):
    def setUp(self):
        self.renderer = SvgDiagramRenderer()
        self.coordinator = DiagramRenderer()

    def test_sequence_svg_generation(self):
        spec = DiagramSpecification(
            title="TCP Handshake Test",
            diagram_type="sequence",
            description="Testing sequence diagram rendering",
            nodes=[
                {"id": "c", "label": "Client", "description": "Local host", "highlight": True},
                {"id": "s", "label": "Server", "description": "Remote host"}
            ],
            connections=[
                {"from": "c", "to": "s", "label": "SYN Packet"}
            ]
        )
        svg = self.renderer.render(spec)
        self.assertTrue(svg.startswith("<svg"))
        self.assertTrue(svg.strip().endswith("</svg>"))
        self.assertIn("TCP Handshake Test", svg)
        self.assertIn("Client", svg)
        self.assertIn("SYN Packet", svg)
        self.assertIn("url(#arrow)", svg)

    def test_cycle_svg_generation(self):
        spec = DiagramSpecification(
            title="Calvin Cycle",
            diagram_type="cycle",
            description="Photosynthesis circular reaction",
            nodes=[
                {"id": "step1", "label": "Carbon Fixation"},
                {"id": "step2", "label": "Reduction"},
                {"id": "step3", "label": "Regeneration"}
            ],
            connections=[
                {"from": "step1", "to": "step2"},
                {"from": "step2", "to": "step3"},
                {"from": "step3", "to": "step1"}
            ]
        )
        svg = self.renderer.render(spec)
        self.assertIn("<circle", svg)
        self.assertIn("Carbon Fixation", svg)
        self.assertIn("RECURRING", svg)

    def test_comparison_svg_generation(self):
        spec = DiagramSpecification(
            title="SQL vs NoSQL",
            diagram_type="comparison",
            nodes=[
                {"id": "sql", "label": "Relational SQL"},
                {"id": "nosql", "label": "Document NoSQL"}
            ]
        )
        svg = self.renderer.render(spec)
        self.assertIn("APPROACH A", svg)
        self.assertIn("APPROACH B", svg)
        self.assertIn("VS", svg)

    def test_hierarchy_svg_generation(self):
        spec = DiagramSpecification(
            title="Tree Hierarchy",
            diagram_type="hierarchy",
            nodes=[
                {"id": "root", "label": "Root"},
                {"id": "left", "label": "Left"},
                {"id": "right", "label": "Right"}
            ],
            connections=[
                {"from": "root", "to": "left"},
                {"from": "root", "to": "right"}
            ]
        )
        svg = self.renderer.render(spec)
        self.assertIn("ROOT", svg)
        self.assertIn("BRANCH", svg)

    def test_html_wrapper(self):
        spec = DiagramSpecification(title="Test", diagram_type="concept_map", nodes=[{"id": "a", "label": "A"}])
        svg = self.renderer.render(spec)
        html_doc = self.coordinator.wrap_svg_in_html(svg, title="My Test")
        self.assertIn("<!DOCTYPE html>", html_doc)
        self.assertIn("<svg", html_doc)


if __name__ == "__main__":
    unittest.main()
