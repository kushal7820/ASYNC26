"""Unit tests for voice trigger detection and debouncing."""

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from speech.trigger_detector import TriggerDetector


class TestTriggerDetector(unittest.TestCase):
    def setUp(self):
        self.detector = TriggerDetector(cooldown_seconds=6.0)

    def test_positive_trigger_phrases(self):
        t0 = 1000.0

        # Exact match
        res = self.detector.check_text("visualize this", current_time=t0)
        self.assertEqual(res, "visualize this")

        # After cooldown, test variations
        t1 = t0 + 10.0
        res = self.detector.check_text("Now class, let us visualize this line on the board.", current_time=t1)
        self.assertEqual(res, "visualize this line")

        t2 = t1 + 10.0
        res = self.detector.check_text("Can you visualize this concept clearly?", current_time=t2)
        self.assertEqual(res, "visualize this concept")

        t3 = t2 + 10.0
        res = self.detector.check_text("Please show me a diagram of the memory layout.", current_time=t3)
        self.assertEqual(res, "show me a diagram")

        t4 = t3 + 10.0
        res = self.detector.check_text("Let's draw this out step by step.", current_time=t4)
        self.assertEqual(res, "draw this")

    def test_negative_sentences(self):
        t0 = 2000.0
        # Sentences without trigger phrases should return None
        res = self.detector.check_text("Today we will discuss how operating systems manage virtual memory.", current_time=t0)
        self.assertIsNone(res)

        res = self.detector.check_text("This visual is quite nice but what about CPU caches?", current_time=t0 + 1.0)
        self.assertIsNone(res)

    def test_cooldown_debouncing(self):
        t0 = 3000.0
        # First trigger fires
        res1 = self.detector.check_text("Teacher says: visualize this", current_time=t0)
        self.assertIsNotNone(res1)

        # Immediate follow-up within 6.0 seconds should be blocked by cooldown
        res2 = self.detector.check_text("Teacher repeats: visualize this again", current_time=t0 + 2.0)
        self.assertIsNone(res2)

        # After cooldown (7 seconds later), should trigger again
        res3 = self.detector.check_text("Now visualize the slide", current_time=t0 + 7.0)
        self.assertIsNotNone(res3)


if __name__ == "__main__":
    unittest.main()
