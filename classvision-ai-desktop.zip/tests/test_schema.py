"""Unit tests for diagram schema validation, repair, and type fallbacks."""

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ai.diagram_schema import (
    DiagramSpecification,
    validate_and_parse_diagram_json,
    SUPPORTED_DIAGRAM_TYPES,
)


class TestDiagramSchema(unittest.TestCase):
    def test_valid_json_parsing(self):
        valid_json = """{
            "title": "HTTP 3-Way Handshake",
            "diagram_type": "sequence",
            "description": "Connection handshake",
            "nodes": [
                {"id": "client", "label": "Client", "description": "Browser"},
                {"id": "server", "label": "Server", "description": "Backend"}
            ],
            "connections": [
                {"from": "client", "to": "server", "label": "SYN"}
            ]
        }"""
        spec = validate_and_parse_diagram_json(valid_json)
        self.assertEqual(spec.title, "HTTP 3-Way Handshake")
        self.assertEqual(spec.diagram_type, "sequence")
        self.assertEqual(len(spec.nodes), 2)
        self.assertEqual(len(spec.connections), 1)
        self.assertEqual(spec.connections[0].from_node, "client")

    def test_markdown_code_fence_stripping(self):
        wrapped_json = """```json
        {
            "title": "CPU Pipeline",
            "diagram_type": "process",
            "nodes": [{"id": "fetch", "label": "Fetch"}]
        }
        ```"""
        spec = validate_and_parse_diagram_json(wrapped_json)
        self.assertEqual(spec.title, "CPU Pipeline")
        self.assertEqual(spec.diagram_type, "process")

    def test_unsupported_type_fallback_to_concept_map(self):
        # AI returned an unsupported type, should fall back to concept_map
        invalid_type_json = """{
            "title": "Quantum Entanglement",
            "diagram_type": "complex_quantum_simulation_matrix",
            "nodes": [{"id": "q1", "label": "Qubit 1"}]
        }"""
        spec = validate_and_parse_diagram_json(invalid_type_json)
        self.assertEqual(spec.diagram_type, "concept_map")

    def test_all_supported_types(self):
        for dtype in SUPPORTED_DIAGRAM_TYPES:
            spec = DiagramSpecification(
                title=f"Test {dtype}",
                diagram_type=dtype,
                nodes=[{"id": "n1", "label": "Node 1"}]
            )
            self.assertEqual(spec.diagram_type, dtype)


if __name__ == "__main__":
    unittest.main()
