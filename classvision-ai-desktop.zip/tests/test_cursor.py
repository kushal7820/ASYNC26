"""Unit tests for cursor position calculation and contextual hint generation."""

import unittest
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from capture.cursor_tracker import calculate_relative_cursor


class TestCursorTracker(unittest.TestCase):
    def test_center_cursor_calculation(self):
        ctx = calculate_relative_cursor(cursor_x=960, cursor_y=540, screen_width=1920, screen_height=1080)
        self.assertEqual(ctx.rel_x, 0.5)
        self.assertEqual(ctx.rel_y, 0.5)
        self.assertEqual(ctx.rel_x_pct, 50)
        self.assertEqual(ctx.rel_y_pct, 50)

    def test_corner_and_clamping(self):
        # Cursor beyond screen boundaries should clamp
        ctx_neg = calculate_relative_cursor(cursor_x=-50, cursor_y=-10, screen_width=1000, screen_height=1000)
        self.assertEqual(ctx_neg.rel_x, 0.0)
        self.assertEqual(ctx_neg.rel_y, 0.0)

        ctx_overflow = calculate_relative_cursor(cursor_x=1200, cursor_y=1100, screen_width=1000, screen_height=1000)
        self.assertEqual(ctx_overflow.rel_x, 1.0)
        self.assertEqual(ctx_overflow.rel_y, 1.0)

    def test_specific_percentage_hint(self):
        # 64% width, 42% height
        ctx = calculate_relative_cursor(cursor_x=640, cursor_y=420, screen_width=1000, screen_height=1000)
        self.assertEqual(ctx.rel_x_pct, 64)
        self.assertEqual(ctx.rel_y_pct, 42)
        hint = ctx.to_hint_string()
        self.assertIn("64% width", hint)
        self.assertIn("42% height", hint)
        self.assertIn("Use this location as a hint", hint)

    def test_zero_dimensions_guard(self):
        ctx = calculate_relative_cursor(cursor_x=10, cursor_y=10, screen_width=0, screen_height=0)
        self.assertIsNotNone(ctx)
        self.assertGreaterEqual(ctx.rel_x, 0.0)


if __name__ == "__main__":
    unittest.main()
