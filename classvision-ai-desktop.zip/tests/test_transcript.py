"""Unit tests for the rolling transcript buffer duration."""

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from speech.transcriber import RollingTranscriptBuffer


class TestTranscriptBuffer(unittest.TestCase):
    def test_buffer_retention_window(self):
        buffer = RollingTranscriptBuffer(max_duration=45.0)

        base_time = 1000.0
        # Add segment at t = 1000 (old)
        buffer.add_segment("This is 60 seconds ago and should expire.", timestamp=base_time)
        # Add segment at t = 1030 (30 seconds later)
        buffer.add_segment("This is 30 seconds ago.", timestamp=base_time + 30.0)
        # Add segment at t = 1055 (55 seconds later)
        buffer.add_segment("This is 5 seconds ago.", timestamp=base_time + 55.0)

        # Current time t = 1060 (60s after first segment)
        # Window of 45s means cutoff is 1060 - 45 = 1015.
        # First segment (at 1000) should be pruned; second (1030) and third (1055) retained.
        recent_text = buffer.get_recent_text(current_time=base_time + 60.0)

        self.assertNotIn("should expire", recent_text)
        self.assertIn("This is 30 seconds ago.", recent_text)
        self.assertIn("This is 5 seconds ago.", recent_text)

    def test_empty_buffer(self):
        buffer = RollingTranscriptBuffer(max_duration=45.0)
        self.assertTrue(buffer.is_empty())
        self.assertEqual(buffer.get_recent_text(), "")

    def test_clear_buffer(self):
        buffer = RollingTranscriptBuffer(max_duration=45.0)
        buffer.add_segment("Sample explanation.", timestamp=100.0)
        self.assertFalse(buffer.is_empty())
        buffer.clear()
        self.assertTrue(buffer.is_empty())


if __name__ == "__main__":
    unittest.main()
