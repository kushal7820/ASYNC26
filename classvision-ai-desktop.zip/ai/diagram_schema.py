"""Strict JSON Schema and models for educational diagrams.
Supports both Pydantic (if installed) and pure Python dataclasses fallback."""

import json
from typing import List, Literal, Optional, Any, Dict
from dataclasses import dataclass, field

# Approved diagram types according to product specification
SUPPORTED_DIAGRAM_TYPES = [
    "flowchart",
    "process",
    "architecture",
    "timeline",
    "cycle",
    "comparison",
    "hierarchy",
    "concept_map",
    "sequence",
    "labeled_diagram",
]


def normalize_diagram_type(v: Any) -> str:
    """Fallback to concept_map if unsupported diagram type is provided."""
    if not isinstance(v, str):
        return "concept_map"
    normalized = v.strip().lower().replace(" ", "_").replace("-", "_")
    if normalized in SUPPORTED_DIAGRAM_TYPES:
        return normalized
    return "concept_map"


try:
    from pydantic import BaseModel, Field, field_validator

    class DiagramNode(BaseModel):
        id: str
        label: str
        description: Optional[str] = None
        group: Optional[str] = None
        highlight: Optional[bool] = False

    class DiagramConnection(BaseModel):
        from_node: str = Field(alias="from")
        to_node: str = Field(alias="to")
        label: Optional[str] = None
        style: Optional[str] = "solid"

        class Config:
            populate_by_name = True

    class DiagramGroup(BaseModel):
        id: str
        label: str
        description: Optional[str] = None

    class DiagramSpecification(BaseModel):
        title: str
        diagram_type: str = "concept_map"
        description: Optional[str] = None
        nodes: List[DiagramNode] = Field(default_factory=list)
        connections: List[DiagramConnection] = Field(default_factory=list)
        groups: Optional[List[DiagramGroup]] = Field(default_factory=list)

        @field_validator("diagram_type", mode="before")
        def validate_dtype(cls, v: Any) -> str:
            return normalize_diagram_type(v)

    HAS_PYDANTIC = True

except ImportError:
    # Pure Python dataclass fallback when pydantic is not yet installed
    @dataclass
    class DiagramNode:
        id: str
        label: str
        description: Optional[str] = None
        group: Optional[str] = None
        highlight: Optional[bool] = False

    @dataclass
    class DiagramConnection:
        from_node: str
        to_node: str
        label: Optional[str] = None
        style: Optional[str] = "solid"

    @dataclass
    class DiagramGroup:
        id: str
        label: str
        description: Optional[str] = None

    @dataclass
    class DiagramSpecification:
        title: str
        diagram_type: str = "concept_map"
        description: Optional[str] = None
        nodes: List[DiagramNode] = field(default_factory=list)
        connections: List[DiagramConnection] = field(default_factory=list)
        groups: Optional[List[DiagramGroup]] = field(default_factory=list)

        def __post_init__(self):
            self.diagram_type = normalize_diagram_type(self.diagram_type)
            # Ensure nodes and connections are typed objects
            processed_nodes = []
            for n in self.nodes:
                if isinstance(n, dict):
                    processed_nodes.append(DiagramNode(**n))
                else:
                    processed_nodes.append(n)
            self.nodes = processed_nodes

            processed_conns = []
            for c in self.connections:
                if isinstance(c, dict):
                    from_val = c.get("from_node", c.get("from", ""))
                    to_val = c.get("to_node", c.get("to", ""))
                    processed_conns.append(DiagramConnection(
                        from_node=from_val,
                        to_node=to_val,
                        label=c.get("label"),
                        style=c.get("style", "solid"),
                    ))
                else:
                    processed_conns.append(c)
            self.connections = processed_conns

        @classmethod
        def model_validate(cls, data: dict) -> "DiagramSpecification":
            return cls(
                title=data.get("title", "Educational Diagram"),
                diagram_type=data.get("diagram_type", "concept_map"),
                description=data.get("description"),
                nodes=data.get("nodes", []),
                connections=data.get("connections", []),
                groups=data.get("groups", []),
            )

    HAS_PYDANTIC = False


def validate_and_parse_diagram_json(raw_json_str: str) -> DiagramSpecification:
    """Parse and validate JSON string into DiagramSpecification with auto-repair."""
    cleaned = raw_json_str.strip()

    # Extract JSON substring from first '{' to last '}'
    start_idx = cleaned.find("{")
    end_idx = cleaned.rfind("}")
    if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
        cleaned = cleaned[start_idx : end_idx + 1]

    data = json.loads(cleaned)

    if HAS_PYDANTIC:
        return DiagramSpecification.model_validate(data)
    else:
        # Dataclass parsing
        return DiagramSpecification.model_validate(data)
