"""Multimodal AI client for ClassVision AI."""

import base64
import json
from pathlib import Path
from typing import Optional, Union, Dict, Any
import requests

from config.settings import settings
from ai.prompts import SYSTEM_PROMPT, build_user_prompt
from ai.diagram_schema import DiagramSpecification, validate_and_parse_diagram_json
from diagram.templates import DEMO_TEMPLATES
from utils.logger import setup_logger

logger = setup_logger()


class MultimodalAIClient:
    """Client for generating educational diagrams from slide + speech + cursor context."""

    def __init__(self, api_key: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or settings.ai_api_key
        self.model = model or settings.ai_model

    def generate_diagram(
        self,
        image_path_or_bytes: Optional[Union[str, Path, bytes]],
        transcript: str,
        cursor_hint: str,
        is_regenerate: bool = False,
        extra_instruction: str = "",
        demo_topic: Optional[str] = None,
    ) -> DiagramSpecification:
        """Call multimodal AI model with slide image, recent transcript, and cursor hint."""
        # Check if running in demo mode or offline fallback
        if settings.demo_mode or demo_topic:
            key = demo_topic.lower() if demo_topic else "tcp"
            if key in DEMO_TEMPLATES:
                logger.info(f"Demo Mode active: Loading built-in template '{key}'")
                return DEMO_TEMPLATES[key]
            return DEMO_TEMPLATES["tcp"]

        if not self.api_key:
            logger.warning("No API key configured for AI generation.")
            raise ValueError(
                "Unable to generate visualization.\n\nReason:\nAI API key is missing.\n"
                "Please configure AI_API_KEY in .env or the Settings panel."
            )

        logger.info(f"Sending multimodal request to {self.model}...")

        # Encode image to base64
        image_b64 = None
        mime_type = "image/png"
        if image_path_or_bytes:
            if isinstance(image_path_or_bytes, bytes):
                image_b64 = base64.b64encode(image_path_or_bytes).decode("utf-8")
            else:
                p = Path(image_path_or_bytes)
                if p.exists():
                    with open(p, "rb") as f:
                        image_b64 = base64.b64encode(f.read()).decode("utf-8")
                    if p.suffix.lower() in [".jpg", ".jpeg"]:
                        mime_type = "image/jpeg"

        user_prompt = build_user_prompt(
            transcript=transcript,
            cursor_hint=cursor_hint,
            is_regenerate=is_regenerate,
            extra_instruction=extra_instruction,
        )

        try:
            raw_json = self._call_gemini_api(image_b64, mime_type, user_prompt)
            logger.info("AI response received. Validating diagram schema...")
            return validate_and_parse_diagram_json(raw_json)
        except Exception as e:
            logger.error(f"AI Generation error: {e}")
            # Try 1 repair attempt if it was a json parse issue
            try:
                repair_prompt = f"The previous response failed schema validation. Return ONLY valid JSON matching the schema for the concept:\n{user_prompt}"
                raw_json = self._call_gemini_api(None, "image/png", repair_prompt)
                return validate_and_parse_diagram_json(raw_json)
            except Exception as repair_err:
                logger.error(f"Repair attempt failed: {repair_err}")
                raise RuntimeError(
                    f"Unable to generate visualization.\n\nReason:\n{str(e)}\n"
                    "Try again or continue teaching with F9 later."
                )

    def _call_gemini_api(
        self, image_b64: Optional[str], mime_type: str, prompt: str
    ) -> str:
        """Execute request to Google Gemini API."""
        endpoint = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"

        parts: list[Dict[str, Any]] = []
        if image_b64:
            parts.append({
                "inline_data": {
                    "mime_type": mime_type,
                    "data": image_b64,
                }
            })
        parts.append({"text": prompt})

        payload = {
            "system_instruction": {
                "parts": [{"text": SYSTEM_PROMPT}]
            },
            "contents": [
                {
                    "role": "user",
                    "parts": parts,
                }
            ],
            "generationConfig": {
                "response_mime_type": "application/json",
                "temperature": 0.2,
            },
        }

        headers = {
            "Content-Type": "application/json",
            "User-Agent": "aistudio-build",
        }

        response = requests.post(endpoint, json=payload, headers=headers, timeout=25)
        if response.status_code != 200:
            raise RuntimeError(f"Gemini API returned HTTP {response.status_code}: {response.text}")

        data = response.json()
        candidates = data.get("candidates", [])
        if not candidates:
            raise RuntimeError("Gemini API returned an empty response.")

        content_parts = candidates[0].get("content", {}).get("parts", [])
        if not content_parts:
            raise RuntimeError("No content parts found in model candidate.")

        return content_parts[0].get("text", "")
