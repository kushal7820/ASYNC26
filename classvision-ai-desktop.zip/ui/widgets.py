"""Custom modern desktop UI components for ClassVision AI."""

from typing import Optional
try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit,
        QPushButton, QFrame
    )
    from PySide6.QtCore import Qt, Signal
    from PySide6.QtGui import QFont, QColor
    from PySide6.QtSvgWidgets import QSvgWidget
except ImportError:
    # Fallback placeholders when running in headless / test environment
    QWidget = object
    QSvgWidget = object
    Signal = lambda *args: None

from core.state import AppStatus


class StatusBadge(QFrame):
    """Pill-style or clean text status indicator for Ready, Listening, Generating, Error."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(12, 6, 12, 6)
        self.layout.setSpacing(8)

        self.dot_label = QLabel("●", self)
        self.text_label = QLabel("Ready", self)
        self.text_label.setFont(QFont("Segoe UI", 10, QFont.Bold))

        self.layout.addWidget(self.dot_label)
        self.layout.addWidget(self.text_label)
        self.set_status(AppStatus.READY)

    def set_status(self, status: AppStatus):
        self.text_label.setText(status.value)
        if status == AppStatus.READY:
            self.dot_label.setStyleSheet("color: #38bdf8; font-size: 14px;")
            self.text_label.setStyleSheet("color: #38bdf8;")
            self.setStyleSheet("background: #0f172a; border: 1px solid #1e293b; border-radius: 14px;")
        elif status == AppStatus.LISTENING:
            self.dot_label.setStyleSheet("color: #34d399; font-size: 14px;")
            self.text_label.setStyleSheet("color: #34d399;")
            self.setStyleSheet("background: #064e3b; border: 1px solid #059669; border-radius: 14px;")
        elif status == AppStatus.GENERATING:
            self.dot_label.setStyleSheet("color: #fbbf24; font-size: 14px;")
            self.text_label.setStyleSheet("color: #fbbf24;")
            self.setStyleSheet("background: #451a03; border: 1px solid #d97706; border-radius: 14px;")
        elif status == AppStatus.ERROR:
            self.dot_label.setStyleSheet("color: #f87171; font-size: 14px;")
            self.text_label.setStyleSheet("color: #f87171;")
            self.setStyleSheet("background: #450a0a; border: 1px solid #dc2626; border-radius: 14px;")


class TranscriptWidget(QFrame):
    """Auto-scrolling display of the rolling ~45s teacher transcript."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)

        header = QLabel("Recent Explanation (~45s Buffer)", self)
        header.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 700; text-transform: uppercase;")
        layout.addWidget(header)

        self.text_area = QTextEdit(self)
        self.text_area.setReadOnly(True)
        self.text_area.setPlaceholderText("Teacher speech transcript will stream here in real-time...")
        self.text_area.setStyleSheet("""
            QTextEdit {
                background: transparent;
                border: none;
                color: #e2e8f0;
                font-size: 13px;
                line-height: 1.5;
            }
        """)
        layout.addWidget(self.text_area)

    def set_text(self, text: str):
        self.text_area.setPlainText(text)
        cursor = self.text_area.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.text_area.setTextCursor(cursor)


class ContextCard(QFrame):
    """Context telemetry displaying slide status, cursor coordinates, and transcript buffer."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QFrame {
                background-color: #0f172a;
                border: 1px solid #1e293b;
                border-radius: 8px;
                padding: 6px;
            }
        """)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)

        self.slide_lbl = QLabel("Current Slide: Ready", self)
        self.slide_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        self.cursor_lbl = QLabel("Cursor: 0, 0 (0%, 0%)", self)
        self.cursor_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        self.buffer_lbl = QLabel("Transcript: 0 words", self)
        self.buffer_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")

        layout.addWidget(self.slide_lbl)
        layout.addWidget(self.cursor_lbl)
        layout.addWidget(self.buffer_lbl)

    def update_context(self, slide_status: str, cursor_str: str, buffer_str: str):
        self.slide_lbl.setText(f"Slide: {slide_status}")
        self.cursor_lbl.setText(f"Cursor: {cursor_str}")
        self.buffer_lbl.setText(f"Transcript: {buffer_str}")
