"""Modern desktop main window for ClassVision AI."""

from typing import Optional
try:
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
        QLabel, QFrame, QSplitter, QMessageBox, QFileDialog
    )
    from PySide6.QtCore import Qt, QTimer, Signal, Slot
    from PySide6.QtGui import QFont, QIcon
    from PySide6.QtSvgWidgets import QSvgWidget
except ImportError:
    QMainWindow = object
    QWidget = object
    Signal = lambda *args: None
    Slot = lambda *args: lambda f: f

from config.settings import settings
from core.state import AppStatus, AppSessionState, VisualizationContext
from core.session import SessionManager
from core.orchestrator import VisualizationOrchestrator
from ui.widgets import StatusBadge, TranscriptWidget, ContextCard
from ui.overlay import OverlayWindow
from ui.settings_window import SettingsWindow
from utils.logger import setup_logger

logger = setup_logger()


class MainWindow(QMainWindow):
    """Main desktop interface for ClassVision AI."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ClassVision AI — AI Teaching Visualizer")
        self.resize(960, 680)

        # Core logic components
        self.session_manager = SessionManager(
            on_trigger_visualize=self._on_hotkey_or_voice_trigger,
            on_transcript_updated=self._on_transcript_updated,
        )
        self.orchestrator = VisualizationOrchestrator(
            session_manager=self.session_manager,
            on_state_changed=self._on_state_changed,
            on_visualization_ready=self._on_visualization_ready,
            on_error=self._on_error,
        )

        # Overlay companion window
        self.overlay = OverlayWindow(on_regenerate=self._handle_regenerate)

        self._init_ui()

    def _init_ui(self):
        """Construct the UI layout."""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #0b0f19;
                color: #f8fafc;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            QPushButton {
                font-weight: 600;
                border-radius: 8px;
            }
        """)

        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(16)

        # 1. Header Bar
        header_bar = QHBoxLayout()
        title_box = QVBoxLayout()
        app_title = QLabel("ClassVision AI", self)
        app_title.setStyleSheet("font-size: 22px; font-weight: 800; color: #f8fafc; letter-spacing: -0.5px;")
        app_subtitle = QLabel("Visualizing every explanation, live.", self)
        app_subtitle.setStyleSheet("font-size: 13px; color: #94a3b8; font-weight: 500;")
        title_box.addWidget(app_title)
        title_box.addWidget(app_subtitle)

        self.status_badge = StatusBadge(self)
        header_bar.addLayout(title_box)
        header_bar.addStretch()

        self.settings_btn = QPushButton("⚙ Settings", self)
        self.settings_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                border: 1px solid #334155;
                padding: 6px 14px;
                font-size: 12px;
            }
            QPushButton:hover {
                color: #f8fafc;
                border-color: #38bdf8;
            }
        """)
        self.settings_btn.clicked.connect(self._open_settings)

        header_bar.addWidget(self.status_badge)
        header_bar.addWidget(self.settings_btn)
        main_layout.addLayout(header_bar)

        # 2. Main Control Action Buttons
        controls_layout = QHBoxLayout()
        controls_layout.setSpacing(12)

        self.session_btn = QPushButton("▶ Start Session", self)
        self.session_btn.setStyleSheet("""
            QPushButton {
                background-color: #0284c7;
                color: #ffffff;
                padding: 12px 24px;
                font-size: 14px;
                border: none;
            }
            QPushButton:hover {
                background-color: #0369a1;
            }
        """)
        self.session_btn.clicked.connect(self._toggle_session)

        self.visualize_btn = QPushButton("✨ Visualize Now (F9)", self)
        self.visualize_btn.setStyleSheet("""
            QPushButton {
                background-color: #4f46e5;
                color: #ffffff;
                padding: 12px 24px;
                font-size: 14px;
                border: none;
            }
            QPushButton:hover {
                background-color: #4338ca;
            }
        """)
        self.visualize_btn.clicked.connect(lambda: self.orchestrator.trigger_visualization(source="UI Button"))

        self.demo_btn = QPushButton("💡 Load Demo Mode", self)
        self.demo_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #38bdf8;
                border: 1px solid #0284c7;
                padding: 12px 18px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #0c4a6e;
            }
        """)
        self.demo_btn.clicked.connect(self._load_demo_mode)

        controls_layout.addWidget(self.session_btn)
        controls_layout.addWidget(self.visualize_btn)
        controls_layout.addWidget(self.demo_btn)
        controls_layout.addStretch()
        main_layout.addLayout(controls_layout)

        # 3. Context Telemetry Bar
        self.context_card = ContextCard(self)
        main_layout.addWidget(self.context_card)

        # 4. Central Splitter: Transcript Panel + Diagram Preview
        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #1e293b;
                width: 4px;
            }
        """)

        # Left: Transcript
        self.transcript_widget = TranscriptWidget(splitter)
        splitter.addWidget(self.transcript_widget)

        # Right: SVG Preview Frame
        preview_frame = QFrame(splitter)
        preview_frame.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)
        pf_layout = QVBoxLayout(preview_frame)
        pf_layout.setContentsMargins(12, 12, 12, 12)
        preview_header = QLabel("Generated Diagram Preview", preview_frame)
        preview_header.setStyleSheet("color: #94a3b8; font-size: 11px; font-weight: 700; text-transform: uppercase;")
        pf_layout.addWidget(preview_header)

        try:
            self.svg_preview = QSvgWidget(preview_frame)
            pf_layout.addWidget(self.svg_preview)
        except Exception:
            self.svg_preview = QLabel("Press F9 or 'Visualize Now' to create diagram", preview_frame)
            self.svg_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.svg_preview.setStyleSheet("color: #64748b; font-size: 13px;")
            pf_layout.addWidget(self.svg_preview)

        splitter.addWidget(preview_frame)
        splitter.setSizes([380, 580])
        main_layout.addWidget(splitter, 1)

    def _toggle_session(self):
        """Start or stop the teaching session."""
        if not self.session_manager.is_active:
            self.session_manager.start_session()
            self.session_btn.setText("■ Stop Session")
            self.session_btn.setStyleSheet("""
                QPushButton {
                    background-color: #b91c1c;
                    color: #ffffff;
                    padding: 12px 24px;
                    font-size: 14px;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #991b1b;
                }
            """)
            self.status_badge.set_status(AppStatus.LISTENING)
        else:
            self.session_manager.stop_session()
            self.session_btn.setText("▶ Start Session")
            self.session_btn.setStyleSheet("""
                QPushButton {
                    background-color: #0284c7;
                    color: #ffffff;
                    padding: 12px 24px;
                    font-size: 14px;
                    border: none;
                }
                QPushButton:hover {
                    background-color: #0369a1;
                }
            """)
            self.status_badge.set_status(AppStatus.READY)

    def _load_demo_mode(self):
        """Load demo slide and simulated teacher explanation."""
        sample_explanation = (
            "The client initiates communication by sending a SYN packet with a random sequence number. "
            "The server receives it, allocates resources, and responds with a SYN-ACK packet. "
            "Finally, the client replies with an ACK packet. At this point, the TCP three-way handshake "
            "is complete and the connection state becomes ESTABLISHED. visualize this"
        )
        self.session_manager.add_transcript_text(sample_explanation)
        self.context_card.update_context(
            slide_status="TCP Slide (Demo)",
            cursor_str="640, 380 (50%, 35%)",
            buffer_str=f"{len(sample_explanation.split())} words"
        )
        self.orchestrator.trigger_visualization(source="Demo Mode", demo_topic="tcp")

    def _on_transcript_updated(self, recent_transcript: str):
        self.transcript_widget.set_text(recent_transcript)
        word_count = len(recent_transcript.split()) if recent_transcript else 0
        self.context_card.update_context(
            slide_status="Active",
            cursor_str="Tracking",
            buffer_str=f"{word_count} words"
        )

    def _on_hotkey_or_voice_trigger(self, source: str):
        self.orchestrator.trigger_visualization(source=source)

    def _on_state_changed(self, state: AppSessionState):
        self.status_badge.set_status(state.status)

    def _on_visualization_ready(self, context: VisualizationContext):
        if context.svg_content:
            # Update main window preview
            try:
                from PySide6.QtCore import QByteArray
                if hasattr(self.svg_preview, "load"):
                    self.svg_preview.load(QByteArray(context.svg_content.encode("utf-8")))
            except Exception as e:
                logger.error(f"Error updating main preview: {e}")

            # Display on-the-spot overlay beside presentation
            title = context.diagram_spec.title if context.diagram_spec else "Educational Diagram"
            self.overlay.display_svg(context.svg_content, diagram_title=title)

    def _on_error(self, err_msg: str):
        logger.error(f"UI Error notification: {err_msg}")

    def _handle_regenerate(self):
        self.orchestrator.regenerate()

    def _open_settings(self):
        dialog = SettingsWindow(self)
        dialog.exec()

    def closeEvent(self, event):
        """Clean shutdown when user closes window."""
        self.session_manager.stop_session()
        self.overlay.close()
        event.accept()
