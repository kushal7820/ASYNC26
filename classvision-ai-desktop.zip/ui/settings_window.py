"""Settings window for ClassVision AI configuration."""

try:
    from PySide6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
        QComboBox, QSpinBox, QPushButton, QFrame, QTextBrowser
    )
    from PySide6.QtCore import Qt
except ImportError:
    QDialog = object

from config.settings import settings


class SettingsWindow(QDialog):
    """Configuration dialog for API keys, models, speech buffer, and privacy."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ClassVision AI — Settings")
        self.resize(520, 520)
        self._init_ui()

    def _init_ui(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #0b0f19;
                color: #f8fafc;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            QLabel {
                color: #cbd5e1;
                font-size: 13px;
                font-weight: 500;
            }
            QLineEdit, QComboBox, QSpinBox {
                background-color: #1e293b;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 8px 12px;
                color: #f8fafc;
                font-size: 13px;
            }
            QPushButton {
                background-color: #0284c7;
                color: #ffffff;
                border: none;
                border-radius: 6px;
                padding: 8px 18px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #0369a1;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(16)

        # Title
        title = QLabel("Application Settings", self)
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #f8fafc;")
        layout.addWidget(title)

        # AI API Key
        layout.addWidget(QLabel("AI API Key (Google Gemini):", self))
        self.api_key_input = QLineEdit(self)
        self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_input.setText(settings.ai_api_key)
        self.api_key_input.setPlaceholderText("Enter AI API Key (or set in .env)")
        layout.addWidget(self.api_key_input)

        # AI Model Selection
        layout.addWidget(QLabel("Multimodal AI Model:", self))
        self.model_combo = QComboBox(self)
        self.model_combo.addItems([
            "gemini-2.5-flash",
            "gemini-3.8-flash",
            "gemini-2.5-pro",
        ])
        self.model_combo.setCurrentText(settings.ai_model)
        layout.addWidget(self.model_combo)

        # Transcript Duration (Buffer)
        layout.addWidget(QLabel("Transcript Retention Buffer (seconds):", self))
        self.duration_spin = QSpinBox(self)
        self.duration_spin.setRange(15, 180)
        self.duration_spin.setValue(int(settings.transcript_duration))
        layout.addWidget(self.duration_spin)

        # Overlay Position
        layout.addWidget(QLabel("Overlay Window Position:", self))
        self.pos_combo = QComboBox(self)
        self.pos_combo.addItems(["Right Side (Beside PPT)", "Left Side", "Float"])
        layout.addWidget(self.pos_combo)

        # Privacy Guarantee Card
        privacy_card = QFrame(self)
        privacy_card.setStyleSheet("""
            QFrame {
                background-color: #0f172a;
                border: 1px solid #1e293b;
                border-radius: 8px;
                padding: 12px;
            }
        """)
        p_layout = QVBoxLayout(privacy_card)
        p_title = QLabel("🔒 Privacy Guarantee", privacy_card)
        p_title.setStyleSheet("font-size: 12px; font-weight: 700; color: #38bdf8;")
        p_desc = QLabel(
            "Speech recognition runs locally via faster-whisper. Raw audio is never uploaded to the cloud. "
            "Only the PowerPoint slide screenshot, recent text transcript, and cursor context are sent to "
            "the multimodal AI API when F9 or a trigger phrase is invoked.",
            privacy_card
        )
        p_desc.setWordWrap(True)
        p_desc.setStyleSheet("font-size: 11px; color: #94a3b8; line-height: 1.4;")
        p_layout.addWidget(p_title)
        p_layout.addWidget(p_desc)
        layout.addWidget(privacy_card)

        layout.addStretch()

        # Action Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        cancel_btn = QPushButton("Cancel", self)
        cancel_btn.setStyleSheet("background-color: #334155; color: #f8fafc;")
        cancel_btn.clicked.connect(self.reject)

        save_btn = QPushButton("Save Settings", self)
        save_btn.clicked.connect(self._save_settings)

        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(save_btn)
        layout.addLayout(btn_layout)

    def _save_settings(self):
        settings.ai_api_key = self.api_key_input.text().strip()
        settings.ai_model = self.model_combo.currentText()
        settings.transcript_duration = float(self.duration_spin.value())
        self.accept()
