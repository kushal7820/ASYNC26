"""Always-on-top educational diagram overlay window for ClassVision AI."""

from typing import Optional, Callable
try:
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
        QScrollArea, QFrame, QSizePolicy
    )
    from PySide6.QtCore import Qt, QPoint, QByteArray
    from PySide6.QtSvgWidgets import QSvgWidget
except ImportError:
    QWidget = object
    QSvgWidget = object

from config.settings import settings
from utils.logger import setup_logger

logger = setup_logger()


class OverlayWindow(QWidget):
    """Floating always-on-top companion window that appears beside PowerPoint slides."""

    def __init__(self, on_regenerate: Optional[Callable[[], None]] = None):
        super().__init__()
        self.on_regenerate = on_regenerate
        self._drag_pos: Optional[QPoint] = None

        self._init_window()
        self._init_ui()

    def _init_window(self):
        """Configure always-on-top, frameless, and translucent properties."""
        # Always on top hint
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)

        # Size and position
        self.resize(settings.overlay_width, settings.overlay_height)
        self._dock_to_right()

        self.setStyleSheet("""
            QWidget {
                background-color: #0b0f19;
                color: #f8fafc;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
        """)

    def _dock_to_right(self):
        """Position window on right side of primary screen, leaving PowerPoint visible."""
        try:
            from PySide6.QtGui import QGuiApplication
            screen = QGuiApplication.primaryScreen().geometry()
            target_x = screen.width() - settings.overlay_width - 24
            target_y = (screen.height() - settings.overlay_height) // 2
            self.move(target_x, target_y)
        except Exception:
            self.move(1380, 150)

    def _init_ui(self):
        """Build overlay UI layout."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(1, 1, 1, 1)
        main_layout.setSpacing(0)

        # Window Container with border
        container = QFrame(self)
        container.setStyleSheet("""
            QFrame {
                background-color: #0b0f19;
                border: 1px solid #1e293b;
                border-radius: 12px;
            }
        """)
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(12, 12, 12, 12)
        container_layout.setSpacing(8)

        # 1. Custom Draggable Title Bar
        title_bar = QFrame(container)
        title_bar.setStyleSheet("background: transparent; border: none;")
        tb_layout = QHBoxLayout(title_bar)
        tb_layout.setContentsMargins(0, 0, 0, 4)

        self.title_label = QLabel("ClassVision AI • Live Diagram", title_bar)
        self.title_label.setStyleSheet("color: #38bdf8; font-weight: 700; font-size: 13px;")

        # Regenerate Button
        self.regen_btn = QPushButton("↻ Regenerate", title_bar)
        self.regen_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #f8fafc;
                border: 1px solid #334155;
                border-radius: 6px;
                padding: 4px 10px;
                font-size: 11px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #334155;
                border-color: #38bdf8;
            }
        """)
        self.regen_btn.clicked.connect(self._handle_regenerate)

        # Close Button
        close_btn = QPushButton("✕", title_bar)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #94a3b8;
                border: none;
                font-size: 16px;
                font-weight: bold;
                padding: 2px 6px;
            }
            QPushButton:hover {
                color: #f87171;
            }
        """)
        close_btn.clicked.connect(self.hide)

        tb_layout.addWidget(self.title_label)
        tb_layout.addStretch()
        tb_layout.addWidget(self.regen_btn)
        tb_layout.addWidget(close_btn)

        container_layout.addWidget(title_bar)

        # 2. SVG Diagram Display Area
        self.scroll_area = QScrollArea(container)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                background: #06090e;
                border: 1px solid #1e293b;
                border-radius: 8px;
            }
        """)

        try:
            self.svg_widget = QSvgWidget(self.scroll_area)
            self.svg_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            self.scroll_area.setWidget(self.svg_widget)
        except Exception:
            self.svg_widget = QLabel("SVG View Unavailable", self.scroll_area)
            self.scroll_area.setWidget(self.svg_widget)

        container_layout.addWidget(self.scroll_area)
        main_layout.addWidget(container)

    def display_svg(self, svg_string: str, diagram_title: str = "Live Diagram"):
        """Render new SVG diagram in the overlay and display the window."""
        self.title_label.setText(f"ClassVision AI • {diagram_title}")
        try:
            if hasattr(self.svg_widget, "load"):
                svg_bytes = QByteArray(svg_string.encode("utf-8"))
                self.svg_widget.load(svg_bytes)
            elif isinstance(self.svg_widget, QLabel):
                self.svg_widget.setText("Diagram Rendered Successfully")
        except Exception as e:
            logger.error(f"Error loading SVG into widget: {e}")

        self.show()
        self.raise_()
        self.activateWindow()

    def _handle_regenerate(self):
        """User clicked regenerate."""
        if self.on_regenerate:
            self.title_label.setText("ClassVision AI • Regenerating...")
            self.on_regenerate()

    # Enable window dragging by clicking anywhere on the header bar
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos is not None:
            self.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
